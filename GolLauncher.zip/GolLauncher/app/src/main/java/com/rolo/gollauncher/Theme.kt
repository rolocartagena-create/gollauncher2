package com.rolo.gollauncher

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Paleta oscura y sobria, con un azul tipo Volkswagen como acento. */
object Gol {
    val bg = Color(0xFF0A0D12)
    val surface = Color(0xFF141922)
    val surface2 = Color(0xFF1D2430)
    val accent = Color(0xFF4FB3FF)
    val text = Color(0xFFE8EDF3)
    val dim = Color(0xFF8B96A3)
}

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gol.accent,
            background = Gol.bg,
            surface = Gol.surface,
            onSurface = Gol.text,
            onBackground = Gol.text,
        ),
        content = content,
    )
}
