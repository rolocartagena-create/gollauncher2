package com.rolo.gollauncher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class MediaUi(
    val hasAccess: Boolean = false,
    val pkg: String? = null,
    val title: String? = null,
    val artist: String? = null,
    val art: Bitmap? = null,
    val playing: Boolean = false,
)

/** Escucha la sesión de medios activa (música sonando) y expone los controles. */
class MediaRepo(private val ctx: Context) {
    private val _state = MutableStateFlow(MediaUi())
    val state: StateFlow<MediaUi> = _state.asStateFlow()

    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val component = ComponentName(ctx, MediaListenerService::class.java)
    private var controller: MediaController? = null

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() = refresh()
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private fun hasAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    /** Llamar desde onResume (el usuario pudo haber dado el permiso mientras estaba fuera). */
    fun start() {
        stop()
        if (!hasAccess()) {
            _state.value = MediaUi(hasAccess = false)
            return
        }
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, component)
            refresh()
        } catch (e: SecurityException) {
            _state.value = MediaUi(hasAccess = false)
        }
    }

    fun stop() {
        try {
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        controller?.unregisterCallback(callback)
        controller = null
    }

    private fun refresh() {
        try {
            pick(msm.getActiveSessions(component))
        } catch (e: SecurityException) {
            _state.value = MediaUi(hasAccess = false)
        }
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(callback)
        controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        controller?.registerCallback(callback)
        publish()
    }

    private fun publish() {
        val c = controller
        if (c == null) {
            _state.value = MediaUi(hasAccess = true)
            return
        }
        val m = c.metadata
        val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM)
        _state.value = MediaUi(
            hasAccess = true,
            pkg = c.packageName,
            title = m?.getString(MediaMetadata.METADATA_KEY_TITLE),
            artist = artist,
            art = art,
            playing = c.playbackState?.state == PlaybackState.STATE_PLAYING,
        )
    }

    fun playPause() {
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
            c.transportControls.pause()
        } else {
            c.transportControls.play()
        }
    }

    fun next() {
        controller?.transportControls?.skipToNext()
    }

    fun previous() {
        controller?.transportControls?.skipToPrevious()
    }
}
