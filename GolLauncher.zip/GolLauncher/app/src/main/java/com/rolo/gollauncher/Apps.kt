package com.rolo.gollauncher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

val NAV_CANDIDATES = listOf(
    "com.google.android.apps.maps",
    "com.waze",
    "com.here.app.maps",
    "com.sygic.aura",
    "ru.yandex.yandexnavi",
)

val MUSIC_CANDIDATES = listOf(
    "com.spotify.music",
    "com.google.android.apps.youtube.music",
    "deezer.android.app",
    "com.apple.android.music",
    "com.amazon.mp3",
    "com.google.android.music",
)

/** Lee todas las apps que se pueden abrir (menos este launcher). */
suspend fun loadApps(ctx: Context): List<AppInfo> = withContext(Dispatchers.Default) {
    val pm = ctx.packageManager
    val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(query, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                pkg = it.activityInfo.packageName,
                icon = it.loadIcon(pm).toBitmap(144, 144).asImageBitmap(),
            )
        }
        .sortedBy { it.label.lowercase() }
}

/** App elegida por el usuario; si no hay, la primera instalada de la lista de candidatas. */
fun resolveSlot(chosen: String?, candidates: List<String>, byPkg: Map<String, AppInfo>): AppInfo? {
    chosen?.let { pkg -> byPkg[pkg]?.let { return it } }
    return candidates.firstNotNullOfOrNull { byPkg[it] }
}

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

fun Context.launchApp(pkg: String?): Boolean {
    if (pkg == null) return false
    val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return false
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try {
        startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }
}

fun Context.openDialer() {
    try {
        startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        toast("No hay app de teléfono")
    }
}

/** Abre la app de navegación directo con la ruta hacia [address]. */
fun Context.navigateTo(address: String, navPkg: String?) {
    val enc = Uri.encode(address)
    val uri = if (navPkg == "com.waze") {
        Uri.parse("waze://?q=$enc&navigate=yes")
    } else {
        Uri.parse("google.navigation:q=$enc")
    }
    val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        if (navPkg != null) intent.setPackage(navPkg)
        startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$enc"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e2: Exception) {
            toast("No hay app de navegación")
        }
    }
}

fun Context.openNotificationAccessSettings() {
    try {
        startActivity(
            Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) {
            toast("Abre Ajustes > Acceso a notificaciones y activa Gol Launcher")
        }
    }
}
