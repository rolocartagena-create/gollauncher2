package com.rolo.gollauncher

import android.service.notification.NotificationListenerService

/**
 * Servicio vacío a propósito: Android solo permite leer las sesiones de medios
 * (lo que suena en Spotify, YouTube Music, etc.) a una app con acceso a notificaciones.
 */
class MediaListenerService : NotificationListenerService()
