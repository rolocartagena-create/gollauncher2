plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.rolo.gollauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rolo.gollauncher"
        // Muchas radios chinas corren Android 8.1 - 10; 21 (Android 5) cubre casi todas.
        minSdk = 21
        // Radio K2001N: Android 10 (API 29)
        targetSdk = 29
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        // Esta es la variante que compila el workflow (assembleDebug). La dejamos optimizada
        // (sin modo depuración y con R8) porque una app Compose en modo debug va lenta en un T3 de 2 GB.
        debug {
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
        release {
            isMinifyEnabled = false
            // Firmado con la llave debug para poder instalarlo directo en la radio.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
