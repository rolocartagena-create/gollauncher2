# Gol Launcher

Launcher minimalista, horizontal y oscuro, inspirado en Android Auto, para una radio china Android.

## Qué hace

- **Barra lateral** con tus apps de navegación, teléfono y música (mantén pulsado un botón para elegir otra app), Inicio, Todas las apps y reloj.
- **Tarjeta de navegación** con botones **Casa** y **Trabajo**: tocas y abre la ruta directo en Google Maps o Waze. Mantén pulsado para cambiar la dirección.
- **Tarjeta de música** que muestra lo que suena (Spotify, YouTube Music, etc.) con portada y controles anterior / play / siguiente.
- **Favoritos** (hasta 4 apps): se añaden desde "Todas las apps" con pulsación larga y se quitan con pulsación larga.
- Pantalla siempre encendida, siempre horizontal, botones grandes.

## Compilar el APK

### Opción A: GitHub Actions (sin instalar nada)
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta.
2. Ve a la pestaña **Actions** > **Compilar APK** > **Run workflow**.
3. Cuando termine (3-6 min), baja el artefacto **GolLauncher-apk** (es un zip con `app-debug.apk`).

### Opción B: Android Studio
1. Abre la carpeta con Android Studio (versión Koala o más nueva).
2. Espera a que sincronice Gradle.
3. Menú **Build > Build APK(s)**. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar en la radio

1. Copia el APK a una memoria USB y ábrelo desde el administrador de archivos de la radio (o instálalo con `adb install app-debug.apk`).
2. Abre **Gol Launcher** una vez.
3. Pulsa **Dar acceso** en la tarjeta de música y activa Gol Launcher en "Acceso a notificaciones". Sin esto no puede mostrar qué suena.
4. Pulsa el botón Home de la radio y elige **Gol Launcher** > **Siempre**. Si tu radio no pregunta, ve a Ajustes > Apps > Apps predeterminadas > Launcher.

> Algunas radios chinas tienen el botón Home atado a su launcher de fábrica. Si no te deja cambiarlo, cuéntame la marca / modelo de la radio y buscamos el truco.

## Ideas para siguientes versiones

- Modo "conducción" con velocidad y brújula (GPS)
- Widget del clima y temperatura exterior
- Atajos a Bluetooth, Wi-Fi y brillo / modo nocturno automático
- Cámara de reversa / de 360° como botón rápido
- Apertura automática de música al conectar el Bluetooth del teléfono
- Fondos y color de acento (por ejemplo, color del auto)
- Recordatorios de mantenimiento (aceite, SOAT, revisión técnica)
- Calculadora de combustible (consumo por tanque)
- Control por voz (Google Assistant)
